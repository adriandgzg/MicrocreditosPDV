﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capa_Entidad
{
    public class CE_CodePayment
    {
        private string _code_payment;

        public string code_payment { get => _code_payment; set => _code_payment = value; }
    }
}
