﻿using Capa_Entidad;
using Capa_Negocio;
using CreditoGS.View;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace CreditoGS.ViewModel
{
    public class CodigoBarrasViewModel : ViewModelBase
    {
        readonly CN_Pagos cN_Pagos = new CN_Pagos();
        private bool _isViewVisibleModal = false;
        private bool _isViewVisible = false;
        private CE_PaymentResp paymentResp = new CE_PaymentResp();
        private CE_PaymentCreditResp creditResp = new CE_PaymentCreditResp();
        private MainViewModel _mainViewModel;

        private DatosModal _datosModal;
        public DatosModal datosModal
        {
            get
            {
                return _datosModal;
            }

            set
            {
                _datosModal = value;
                OnPropertyChanged(nameof(datosModal));
            }
        }

        private int _tipotarea;
        public int TipoTarea
        {
            get
            {
                return _tipotarea;
            }

            set
            {
                _tipotarea = value;
                OnPropertyChanged(nameof(TipoTarea));
            }
        }

        private string _mensaje;
        public string Mensaje
        {
            get
            {
                return _mensaje;
            }

            set
            {
                _mensaje = value;
                OnPropertyChanged(nameof(Mensaje));
            }
        }

        private string _nombre;
        public string Nombre
        {
            get
            {
                return _nombre;
            }

            set
            {
                _nombre = value;
                OnPropertyChanged(nameof(Nombre));
            }
        }

        private string _monto;
        public string Monto
        {
            get
            {
                return _monto;
            }

            set
            {
                _monto = value;
                OnPropertyChanged(nameof(Monto));
            }
        }

        private string _codigobarra;
        public string CodigoBarra
        {
            get
            {
                return _codigobarra;
            }

            set
            {
                _codigobarra = value;
                OnPropertyChanged(nameof(CodigoBarra));
            }
        }
        private bool _creditShow = false;
        public bool CreditShow
        {
            get
            {
                return _creditShow;
            }

            set
            {
                _creditShow = value;
                OnPropertyChanged(nameof(CreditShow));
            }
        }

        public bool IsViewVisibleModal
        {
            get
            {
                return _isViewVisibleModal;
            }

            set
            {
                _isViewVisibleModal = value;
                OnPropertyChanged(nameof(IsViewVisibleModal));
            }
        }

        public bool IsViewVisible
        {
            get
            {
                return _isViewVisible;
            }

            set
            {
                _isViewVisible = value;
                OnPropertyChanged(nameof(IsViewVisible));
            }
        }

        public ICommand ExecuteCommand { get; }

        public ICommand BackCommand { get; }
        public ICommand PagarCreditoCommand { get; }
        public ICommand PagarCommand { get; }

        public MainViewModel mainViewModel { get => _mainViewModel; set => _mainViewModel = value; }

        DatosModal datosModal1;
        public CodigoBarrasViewModel()
        {
            ExecuteCommand = new ViewModelCommand(ExecutePagarCommand);
            BackCommand = new ViewModelCommand(ExecuteBack);
            PagarCreditoCommand = new ViewModelCommand(ExecutePagoCredito);
            PagarCommand = new ViewModelCommand(ExecutePago);

            //datosModal = new DatosModal(this);
        }

        private async void ExecuteBack(object obj)
        {
            IsViewVisible = false;
            mainViewModel.IsViewVisible = true;
        }

        private async void ExecutePago(object obj)
        {
            string token = (string)App.Current.Properties["TokenAuth"];
            //datosModal.Hide();
            //IsViewVisible = false;
            //mainViewModel.IsViewVisible = true;
            //CodigoBarra = "";
            //return;
            if (paymentResp != null)
            {
                var res = await cN_Pagos.PagarProducto(new Capa_Entidad.CE_PayPayment()
                {
                    amount_pay = paymentResp.data.amount_pay,
                    idclient = paymentResp.data.info_client.idcliente,
                    idcode = paymentResp.data.idcode,
                    branch_number = "C-56"

                }, token);

                if (res != null)
                    if (res.issuccess)
                    {
                        MessageBox.Show(res.message, "Mensaje", MessageBoxButton.OK, MessageBoxImage.Information);
                        datosModal.Hide();
                        IsViewVisible = false;
                        mainViewModel.IsViewVisible = true;
                    }
                    else
                        MessageBox.Show(res.message, "Mensaje", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
        private async void ExecutePagoCredito(object obj)
        {
            string token = (string)App.Current.Properties["TokenAuth"];
            //datosModal.Hide();
            //IsViewVisible = false;
            //mainViewModel.IsViewVisible = true;
            //CodigoBarra = "";
            //return;
            if (creditResp != null)
            {
                var res = await cN_Pagos.PagarCredito(new Capa_Entidad.CECreditPayment()
                {
                    amount_pay = creditResp.data.amount_pay,
                    idclient = creditResp.data.info_client.idcliente,
                    idcode = creditResp.data.idcode,
                    branch_number = "C-56",
                    idcredit = creditResp.data.idcredit
                }, token);

                if (res != null)
                    if (res.issuccess)
                    {
                        MessageBox.Show(res.message, "Mensaje", MessageBoxButton.OK, MessageBoxImage.Information);
                        datosModal.Hide();
                        IsViewVisible = false;
                        mainViewModel.IsViewVisible = true;
                    }
                    else
                        MessageBox.Show(res.message, "Mensaje", MessageBoxButton.OK, MessageBoxImage.Warning);
                
            }
            else
            {
                MessageBox.Show("Ocurrio un error al intentar realizar el pago, si el problema persiste contacte al administrador.", "Mensaje", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
        private async void ExecutePagarCommand(object obj)
        {
            string token = (string)App.Current.Properties["TokenAuth"];
            switch (TipoTarea)
            {
                case 1:
                    var response = await cN_Pagos.BuscarCodigoPago(new Capa_Entidad.CE_CodePayment() { code_payment = CodigoBarra }, token);

                    if (response != null)
                        if (response.issuccess)
                        {
                            CreditShow = true;
                            paymentResp = response;
                            Mensaje = "";
                            IsViewVisibleModal = true;
                            datosModal = new DatosModal(this, response.data.info_client.fullname, string.Format("{0:C2}", response.data.amount_pay), false);
                            datosModal.ShowDialog();
                            //var res = await cN_Pagos.PagarProducto(new Capa_Entidad.CE_PayPayment()
                            //{
                            //    amount_pay = response.data.amount_pay,
                            //    idclient = response.data.info_client.idcliente,
                            //    idcode = response.data.idcode,
                            //    branch_number = "C-56"

                            //}, token);

                            //if (res != null)
                            //    if (res.issuccess)
                            //    {


                            //        MessageBox.Show(res.message, "Mensaje", MessageBoxButton.OK, MessageBoxImage.Information);
                            //    }
                            //    else
                            //        MessageBox.Show(res.message, "Mensaje", MessageBoxButton.OK, MessageBoxImage.Warning);


                        }
                        else
                            MessageBox.Show(response.message, "Mensaje", MessageBoxButton.OK, MessageBoxImage.Warning);
                    break;
                case 2:
                    var responseC = await cN_Pagos.BuscarCodigoAbono(new Capa_Entidad.CE_CodePayment() { code_payment = CodigoBarra }, token);

                    if (responseC != null)
                        if (responseC.issuccess)
                        {
                            creditResp = responseC;
                            IsViewVisibleModal = true;
                            CreditShow = true;
                            Mensaje = "Reciba la cantidad de " + string.Format("{0:C2}", responseC.data.amount_pay) + " por parte del cliente";
                            Monto = string.Format("{0:C2}", responseC.data.amount_pay);
                            Nombre = responseC.data.info_client.fullname;
                            //ModalWindow modalWindow = new ModalWindow("Reciba la cantidad de " + string.Format("{0:C2}", responseC.data.amount_pay) + " por parte del cliente", this);
                            //modalWindow.ShowDialog();
                            datosModal = new DatosModal(this, responseC.data.info_client.fullname, string.Format("{0:C2}", responseC.data.amount_pay), true);
                            datosModal.ShowDialog();
                            IsViewVisibleModal = true;
                        }
                        else
                            MessageBox.Show(responseC.message, "Mensaje", MessageBoxButton.OK, MessageBoxImage.Warning);
                    break;
                case 3:
                    await cN_Pagos.BuscarCodigoPago(new Capa_Entidad.CE_CodePayment() { code_payment = CodigoBarra }, token);
                    break;
            }
        }
    }
}
